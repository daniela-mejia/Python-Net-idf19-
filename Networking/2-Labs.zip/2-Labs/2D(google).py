import socket

print("IP Address : %s" %socket.gethostbyname('www.google.com'))
