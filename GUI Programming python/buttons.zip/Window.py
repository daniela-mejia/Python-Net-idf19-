#This program Displays an empty window

import tkinter

def main ():
    #create the main window widget (PREDETERMINE)
    main_window = tkinter.Tk()


    #Enter the tkinter main loop (SO IT KEEP SHOWING WINDOW UNTIL EXIT OUT)
    tkinter.mainloop()

#call the main function
main()
    
